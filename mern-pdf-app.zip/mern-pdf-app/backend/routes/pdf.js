const express = require('express');
const multer = require('multer');
const PDF = require('../models/PDF');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});

const upload = multer({ storage, limits: { fileSize: 1000000 }, fileFilter: (req, file, cb) => {
  if (file.mimetype === 'application/pdf') cb(null, true);
  else cb(new Error('Only PDFs are allowed'), false);
}});

router.post('/upload', auth, upload.single('pdf'), async (req, res) => {
  try {
    const pdf = new PDF({
      filename: req.file.filename,
      path: req.file.path,
      size: req.file.size,
      uploadedBy: req.user.id,
    });
    await pdf.save();
    res.status(201).json(pdf);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/all', auth, async (req, res) => {
  try {
    const pdfs = await PDF.find({ uploadedBy: req.user.id });
    res.json(pdfs);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
